#include "DeviceIndependentInterfaces.h"

IHttpClient::~IHttpClient() {
}
IDateTimeProvider::~IDateTimeProvider() {
}

